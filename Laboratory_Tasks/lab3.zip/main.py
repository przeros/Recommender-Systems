import csv
import pandas as pd

def unalikeability_metric(feature_values):
    n = len(feature_values)
    unalikeability = 0

    for i in range(n):
        for j in range(n):
            if i != j:
                c_xi_xj = 0 if feature_values[i] == feature_values[j] else 1
                unalikeability += c_xi_xj
    unalikeability /= (n ** 2 - n)
    return unalikeability


def calculate_unalikeability(data):
    unalikeability_scores = {}

    for i in range(12):
        feature_values = data[i]
        unalikeability_scores[i] = unalikeability_metric(feature_values)

    return unalikeability_scores


def main():
    context_params = ['time', 'daytype', 'season', 'location', 'weather', 'social', 'endEmo', 'dominantEmo', 'mood', 'physical', 'decision', 'interaction']
    # Replace 'your_file.csv' with the actual file path
    columns = {}
    for i in range(3, 15):
        columns[i - 3] = list()
    with open('LDOS-CoMoDa.csv', 'r') as csvfile:
        for row in csv.reader(csvfile, delimiter=';'):
            for i in range(3, 15):
                columns[i - 3] += row[i]

    unalikeability_scores = calculate_unalikeability(columns)

    # Get the top 5 features with the highest unalikeability scores
    top_features = sorted(unalikeability_scores.items(), key=lambda x: x[1], reverse=True)[:5]

    print("Top 5 features based on unalikeability:")
    for feature, score in top_features:
        print(f"{context_params[feature]}: {score}")


if __name__ == "__main__":
    main()