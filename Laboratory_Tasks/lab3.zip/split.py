import random
from collections import defaultdict

def split_data_stratified(input_file, train_file, test_file, split_ratio):
    with open(input_file, 'r') as input_file:
        lines = input_file.readlines()

    user_data = defaultdict(list)

    for line in lines:
        user_id, *data = line.strip().split(",")
        user_data[user_id].append(",".join([user_id] + data))

    train_data = []
    test_data = []

    for user_id, data in user_data.items():
        num_samples = len(data)
        split_index = int(num_samples * split_ratio)
        train_data.extend(data[:split_index])
        test_data.extend(data[split_index:])

    random.shuffle(train_data)
    random.shuffle(test_data)

    with open(train_file, 'w') as train_file:
        train_file.write("\n".join(train_data))

    with open(test_file, 'w') as test_file:
        test_file.write("\n".join(test_data))


if __name__ == "__main__":
    input_file = "LDOS-CoMoDa.csv"
    train_file = "LDOS-CoMoDa_train.csv"
    test_file = "LDOS-CoMoDa_test.csv"
    split_ratio = 0.6

    split_data_stratified(input_file, train_file, test_file, split_ratio)